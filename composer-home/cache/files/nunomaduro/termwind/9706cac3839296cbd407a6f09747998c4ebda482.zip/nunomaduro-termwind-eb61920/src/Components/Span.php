<?php

declare(strict_types=1);

namespace Termwind\Components;

final class Span extends Element
{
    // ..
}
